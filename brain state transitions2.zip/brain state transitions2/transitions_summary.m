%%% Path for Recordings:
path(path, '/home/franz/Windows/Data/Programming/Utility');
backup = '/media/Backup1/Data/RawData';
root = '/home/franz/Windows/Data/RawData';



confpath = '/home/franz/Windows/Data/RawData';
%%% Path for storing figures:
out_path = '';

%%% trace file: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rec_file = 'vmgad_20mean_stim.txt';
%rec_file = 'remonline_vmgad.txt';
%rec_file = 'bla.txt';
%rec_file = 'vmgad_control_20mean_stim.txt';
%rec_file = 'G93_stim.txt';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% Load Recordings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen( fullfile(confpath, rec_file) );
s = fscanf(fid, '%c', inf);
fclose(fid); 
lines = regexp(s, '\n', 'split');

clear R; j=1;
for i=1:length(lines)
    l = lines{i};
    
    if regexp(l, '^#')
        continue;
    end
    
    if (isempty(l)>0) || ~isempty(regexp(l, '^\s'))
        newline = 1;
        continue;
    end
    a = regexp(l, '\s+', 'split');
    
    if (strcmp(a{1}, 'E') == 1)
        R(j).name = a{2};
        name = a{2};
        a = regexp(name, '_', 'split');
        R(j).idf = a{1};
        j = j+1;
    end
end
%%% END[Load Recordings] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% get all mice - not just recordings
Rdict = containers.Map;
for i=1:length(R)
    idf = R(i).idf;
    Rdict(idf) = 1;
end
Mouse = Rdict.keys;


%%
%%% count transitions
for i=1:length(R)
    [~,MX, C, t] = transition_count(backup, R(i).name);
    R(i).MX = MX;
    R(i).C  = C;
end
nseq = size(MX,3);

%%
aMX = zeros(size(R(1).MX));
aC  = zeros(size(R(1).C));
for i=1:length(R)
    aMX = aMX + R(i).MX;
    aC  = aC  + R(i).C;
end

pMX = aMX;
% for j=1:size(aMX,3)
%     for s=1:3
%         tmp = aC(s,j);
%         tmp(tmp==0) = 1;
%         pMX(s,:,j) = pMX(s,:,j) ./ tmp;
%         %pMX(s,:,j) = mean(pMX(s,:,:),3) ./ aC(s,j);
%         %pMX(s,:,j) =  aC(s,j);
%         
%         ii = find(t<0);
%         if s==1 
%             
%             pMX(1,2,j) = mean(pMX(1,2,ii)) ./ mean(aC(1,ii));
%         end
%         
%         
%     end
% end


for si=1:3
    for sj=1:3 
        tmp = pMX(si,sj,:);
        tmp = reshape(tmp, [1,nseq]);
        tmp2 = aC(si,:);
        %tmp2(tmp2==0) = 1;
        pMX(si,sj,:) = tmp ./ tmp2;
        
        ii = find(t<0);
        jj = find(t>200);
        if si==1 && sj==2
            pMX(1,2,ii) = mean(tmp(ii)) ./ mean(aC(1,ii));
            %pMX(1,2,jj) = nanmean(tmp(jj)) ./ nanmean(aC(1,jj));
            pMX(1,2,jj) = nan;
        end
    end
end



%%

figure;
for si=1:3
    for sj=1:3
        %TM = reshape(AMX(si,sj,:,:), [nseq, length(Mouse)])';
        subplot(3,3,(si-1)*3+sj); hold on;
        set(gca, 'FontSize', 15);
        patch([0, 120, 120, 0], [0, 0, 1, 1], [0.8 0.8 1], 'EdgeColor', 'none');
        
        %if si ~= sj
            plot(t,reshape(pMX(si,sj,:), [1, size(aMX,3)]), 'b--o', 'LineWidth', 2);
        %end
        %JackKnife(t,nanmean(TM), std(TM)./sqrt(6));
        ylim([0 1]);
        xlim([t(1) t(end)]);
        
        
        if si==1 && sj==1
            ylabel('REM');
            title('REM');
        end
        if si==1 && sj==2
            title('Wake');
        end
        if si==1 && sj==3
            title('NREM');
        end
        if si==2 && sj==1
            ylabel('Wake');
        end
        if si==3 && sj==1
            ylabel('NREM');
        end
      
        
        
    end
end




%%
%%% Mouse Averaging
Rmap = containers.Map;
% Rmap: Mouse IDF -> Integer
j=1;
for i=1:length(Mouse)
    idf = Mouse{i};
    Rmap(idf) = j;
    j=j+1;
end


AMX = zeros(3,3,nseq, length(Mouse));
AC  = zeros(3, nseq, length(Mouse));
count = zeros(1, length(Mouse));
for i=1:length(R)
    idf = R(i).idf;
    j = Rmap(idf);
    
    AMX(:,:,:,j) = AMX(:,:,:,j) + R(i).MX;
    AC(:,:,j)    = AC(:,:,j)    + R(i).C;
    
    count(j) = count(j)+1;
end


for i=1:length(Mouse)
    AMX(:,:,:,i) = AMX(:,:,:,i) ./ count(i);
    AC(:,:,i) = AC(:,:,i) ./ count(i);
    
    for j=1:nseq
        for s=1:3
%             if s==1
%                 %a = mean(AC(s,:,i)); 
%                 a = mean(mean(AC(s,:,:)));
%                 AMX(s,:,j,i) = AMX(s,:,j,i) ./ a; 
%             else
                AMX(s,:,j,i) = AMX(s,:,j,i) ./ AC(s,j,i); 
           
        end
    end
end

%%
si=1; sj=3;
dt = 30;
%t = (dt:dt:dt*size(pMX,3))-600+dt/2;

TM = reshape(AMX(si,sj,:,:), [nseq, length(Mouse)])';
figure; 
hold on;
patch([0, 120, 120, 0], [0, 0, 1, 1], [0.8 0.8 1], 'EdgeColor', 'none');
JackKnife(t,nanmean(TM), std(TM)./sqrt(6));
ylim([0 1]);
xlim([t(1) t(end)]);
set(gca, 'FontSize', 25);
set(gca, 'LineWidth', 1.5);
set(gca, 'YTick', [0 0.5 1]);

%%
figure;
for si=1:3
    for sj=1:3
        TM = reshape(AMX(si,sj,:,:), [nseq, length(Mouse)])';
        subplot(3,3,(si-1)*3+sj); hold on;
        patch([0, 120, 120, 0], [0, 0, 1, 1], [0.8 0.8 1], 'EdgeColor', 'none');
        JackKnife(t,mean(TM), std(TM)./sqrt(6));
        ylim([0 1]);
        xlim([t(1) t(end)]);
    end
end















