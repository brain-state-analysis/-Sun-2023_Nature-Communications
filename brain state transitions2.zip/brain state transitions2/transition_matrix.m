function [MX,t] = transition_matrix(ppath, name, pre, post, down)
%
%
% %R   -    structure with fields, R(i).ppath and R(i).name


%%% Fixed Parameters
SR = 1525.88;
ds = round(down/2.5002);
%pre = 600;
%post = 720;
dt = (1/SR)*(round(SR)*5/2)*ds;  % number of downsampled time step
nbins = (round(SR)*5/2)*ds;   
ipre = round(pre/dt);
ipost = round(post/dt);
nseq = ipre+ipost+1;
t = (-pre+dt/2):dt:post+dt;
t = t(1:nseq-1);

file = fullfile(ppath, name, ['remidx_' name '.txt']);
if ~exist(file, 'file')
    display([name ': no state file']);
    [M,S]=sleep_state5(ppath, name);
else
    [M,S] = load_stateidx(ppath, name);
end
M = downsample_states(M, ds);

%%% load laser signal
ddir = fullfile(ppath, name);
A = load(fullfile(ddir, ['laser_' name '.mat']));
idx_lsr = laser_start_end(A.laser, SR);
%%% downsample laser signal, need to think about...
for i=1:size(idx_lsr,1)
    %idx_lsr(i,:) = floor(idx_lsr(i,:)./nbins)+1;
    % I'm taking the laser laser free trial
    idx_lsr(i,:) = floor((idx_lsr(i,:)-1)./nbins)+1;
    
    %idx_lsr(i,:) = round((idx_lsr(i,:))./nbins);
    %idx_lsr(i,:) = ceil((idx_lsr(i,:))./nbins)+1;
end


j=0;
for i=1:size(idx_lsr,1)
    if (idx_lsr(i,1)-ipre > 0) && (idx_lsr(i,1)+ipost < length(M))
        j=j+1;
    end    
end
nrows = j;

MX = zeros(nrows, nseq);
j=1;
for i=1:size(idx_lsr,1)
    if (idx_lsr(i,1)-ipre > 0) && (idx_lsr(i,1)+ipost < length(M))
        MX(j,:) = M(idx_lsr(i,1)-1-ipre:idx_lsr(i,1)+ipost-1);
        %%% the "-1" is here because I want to make sure that there are
        %%% $pre transitions before the onset of laser. 
        j=j+1;
    end    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mds = downsample_states(M, nbin)
n = floor(length(M) / nbin);
Mds = zeros(n,1);
for i=1:n
    m = M((i-1)*nbin+1:i*nbin);
    S = zeros(1,3);
    for s=1:3
        S(s) = length(find(m==s));
    end
    [~,ii] = max(S);
    Mds(i) = ii;
end

