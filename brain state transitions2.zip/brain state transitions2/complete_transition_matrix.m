function [MX, C] = complete_transition_matrix(ppath, name, pre, post, down, plaser)


%%% Fixed Parameters
SR = 1525.88;
ds = round(down/2.5002);
%pre = 600;
%post = 720;
dt = (1/SR)*(round(SR)*5/2)*ds;  % number of downsampled time step
nbins = (round(SR)*5/2)*ds;
ipre = round(pre/dt);
ipost = round(post/dt);
nseq = ipre+ipost+1;


file = fullfile(ppath, name, ['remidx_' name '.txt']);
if ~exist(file, 'file')
    display([name ': no state file']);
    [M,S]=sleep_state5(ppath, name);
else
    [M,S] = load_stateidx(ppath, name);
end
M = downsample_states(M, ds);

if plaser == 1
    %%% load laser signal
    ddir = fullfile(ppath, name);
    A = load(fullfile(ddir, ['laser_' name '.mat']));
    idx_lsr = laser_start_end(A.laser, SR);
    %%% downsample laser signal, need to think about...
    for i=1:size(idx_lsr,1)
        % I'm taking here the first bin with laser
        idx_lsr(i,:) = floor((idx_lsr(i,:)-1)./nbins)+1;
    end
    
    seq_lsr = [];
    for i=1:size(idx_lsr,1)
        seq_lsr = [seq_lsr idx_lsr(i,1):idx_lsr(i,1)+ipost];
    end
    
    no_lsr = setdiff(1:length(M), seq_lsr);
else
    no_lsr = 1:length(M);
end

MX = zeros(3,3);
C  = zeros(1,3);
%%% si -> sj
for i=1:length(no_lsr)-1
    si = no_lsr(i);
    sj = no_lsr(i+1);
    if (sj-si) == 1
        MX(M(si), M(sj)) = MX(M(si), M(sj)) + 1;
        C(M(si)) = C(M(si)) + 1;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mds = downsample_states(M, nbin)
n = floor(length(M) / nbin);
Mds = zeros(n,1);
for i=1:n
    m = M((i-1)*nbin+1:i*nbin);
    S = zeros(1,3);
    for s=1:3
        S(s) = length(find(m==s));
    end
    [~,ii] = max(S);
    Mds(i) = ii;
end
