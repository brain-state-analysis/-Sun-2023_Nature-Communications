%%% Path for Recordings:
path(path, '/home/franz/Windows/Data/Programming/Utility');
backup = '/media/Backup1/Data/RawData';
root = '/home/franz/Windows/Data/RawData';
%backup = root;

confpath = '/home/franz/Windows/Data/RawData';
%%% Path for storing figures:
out_path = '';

%%% trace file: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%rec_file = 'vmgad_20mean_stim_nat.txt';
rec_file = 'vlpag_5mincontrol_stim.txt';
%rec_file = 'G93_stim.txt';
%rec_file = 'remonline_vmgad.txt';
%rec_file = 'bla.txt';
%rec_file = 'vmgad_control_20mean_stim.txt';
%rec_file = 'G56_stim.txt';
%rec_file = 'tmp_tmp.txt';
%rec_file = 'ponsvglut_stim.txt';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Parameters to choose %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
psave = 0;
down = 30; % BEFORE 20
pre = 180; % BEFORE 180
post = 120+pre;
pre = 300;
post = 300+pre;
laser_tend = 300;

%%
%%% Load Recordings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen( fullfile(confpath, rec_file) );
s = fscanf(fid, '%c', inf);
fclose(fid); 
lines = regexp(s, '\n', 'split');

clear R; j=1;
for i=1:length(lines)
    l = lines{i};
    
    if regexp(l, '^#')
        continue;
    end
    
    if (isempty(l)>0) || ~isempty(regexp(l, '^\s'))
        newline = 1;
        continue;
    end
    a = regexp(l, '\s+', 'split');
    
    if (strcmp(a{1}, 'E') == 1)
        R(j).name = a{2};
        name = a{2};
        a = regexp(name, '_', 'split');
        R(j).idf = a{1};
        j = j+1;
    end
end
%%% END[Load Recordings] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%%% Markov matrix for data without laser
CMX = zeros(3,3);
CC  = zeros(1,3);
for i=1:length(R)
    if exist(fullfile(root, R(i).name), 'dir')
        ppath = root;
    else
        ppath = backup;
    end
    R(i).ppath = ppath;
    [a,b] = complete_transition_matrix(ppath, R(i).name, 0, 120, down, 1);
    CMX = CMX + a;
    CC  = CC  + b;
end

for si=1:3
    for sj=1:3
        CMX(si,sj) = CMX(si,sj) / CC(si);
    end
end


%%
%%% build up large matrix
MX = [];
for i=1:length(R)
    [mx, t] = transition_matrix(R(i).ppath, R(i).name,pre,post,down);
    MX = [MX; mx];
end

%%
%%% set seed 
rand('seed', 928374);
%rand('seed', 10);
nboot = 1000;
nrows = size(MX,1);
nseq = size(MX,2)-1;

M = cell(1,9);
for i=1:nboot
    M{i} = zeros(nboot, nseq);
end

for b=1:nboot
    idx = randi(nrows,[nrows,1]);
    bMX = build_markov_matrix(MX(idx,:));
    for si=1:3
        for sj=1:3
            id = (si-1)*3+sj;
            M{id}(b,:) = reshape(bMX(si,sj,:), [1, size(bMX,3)]);
        end
    end 
end


%%
alpha = 0.05;
sf = 0.0;
figure;
for si=1:3
    for sj=1:3
        %TM = reshape(AMX(si,sj,:,:), [nseq, length(Mouse)])';
        id = (si-1)*3+sj;
        subplot(3,3,id); hold on;
        set(gca, 'FontSize', 10);
        
        %if si ~= sj
        
        P = M{id};
        P(isnan(P)) = 0;
        
        if si==1
            Q = [P P P];
            if sf > 0
            for i=1:size(P,1)
                Q(i,:) = smooth_data(Q(i,:), sf);
            end
            end
            P = Q(:,size(Q,2)/3+1:(size(Q,2)/3)*2);
        end
        
        
        patch([0, laser_tend, laser_tend, 0], [0, 0, 1.05, 1.05], [0.6 0.6 1], 'EdgeColor', 'none');
        %bar(t, nanmean(M{id}), 'FaceColor', 'w');
        bar(t, nanmean(P), 'FaceColor', 'w');
        
        % get errorbars: "1-alpha" confidence interval;
        %S = M{id};
        S = P;
        for i=1:size(S,2)
            S(:,i) = sort(S(:,i));
        end
        Bounds = zeros(2, size(S,2));
        Bounds(1,:) = -S(nboot*(alpha/2),:) + nanmean(S);
        Bounds(2,:) = S(end-nboot*(alpha/2),:) - nanmean(S);
        
        
        %H=errorbar(t, nanmean(M{id}), nanstd(M{id}), '.', 'Color', 'k', 'LineWidth', 1);
        H=errorbar(t, nanmean(P), Bounds(1,:), Bounds(2,:), '.', 'Color', 'k', 'LineWidth', 1);
        
        
        errorbar_tick(H,10000);
        plot(t, ones(1,length(t))*CMX(si,sj), '--', 'Color', [1 0 0], 'LineWidth', 1);
        %JackKnife(t, nanmean(M{id}), nanstd(M{id}));
        
        dt = t(2)-t(1);
        xlim([t(1)-dt, t(end)+dt/2]);
        set(gca, 'XTick', [0 laser_tend]);
        %end
        ylim([0 1.05]);
        
        if si==1 && sj==1
            ylabel('REM');
            title('REM');
        end
        if si==1 && sj==2
            title('Wake');
        end
        if si==1 && sj==3
            title('NREM');
        end
        if si==2 && sj==1
            ylabel('Wake');
        end
        if si==3 && sj==1
            ylabel('NREM');
        end
    end
end


outpath = '/home/franz/Windows/Data/TexCentral/VMPaper/Figures/Transitions';
if psave == 1
    file = fullfile(outpath, 'fig_vlpag_transitions');
    print('-dpdf', file);
end


%%
mapping = [1 2 3; 4 5 6; 7 8 9];
State = {'REM', 'Wake', 'NREM'}

ii = find(t>-laser_tend & t<0);
ij = find(t>=0 & t<laser_tend);

for si=1:3
    for sj=1:3
        C = M{mapping(si,sj)};
        
        data = mean(C(:,ij),2);
        D = data-CMX(si,sj);
        
        p = length(find(D>=0)) / length(D);
        
        fprintf('%s -> %s: A percentage of P= %f trials is larger than the baseline\n', State{si}, State{sj}, p);
        
    end
end










