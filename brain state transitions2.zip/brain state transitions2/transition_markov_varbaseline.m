
%%% FIXED PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iseed = 928374;
% path(path, '/home/franz/Windows/Data/Programming/Utility');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Backup folder for Recordings [optional]:
backup = 'J:\Analysed Data\NTS_POA\Franz_Methods';
% where reocrding folders are stored 
root = 'J:\Analysed Data\NTS_POA\Franz_Methods';
% path where $rec_file is located:
confpath = 'J:\Analysed Data\NTS_POA\Franz_Methods';
%%% Path and Name for storing figure:
outpath = 'J:\Analysed Data\NTS_POA\Franz_Methods';
fig_name = 'transition_figure.pdf';

%%% trace file: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% file listing all recordings; list all recordings using the following syntax:
% # marks a comment which is discarded
% E     "Recording1"
% E     "Recording2"
% # etc.
%
%rec_file = 'vmgad_20mean_stim_nat.txt';
%rec_file = 'vlpag_5mincontrol_stim.txt';
%rec_file = 'G93_stim.txt';
%rec_file = 'remonline_vmgad.txt';
%rec_file = 'bla.txt';
%rec_file = 'vmgad_control_20mean_stim.txt';
%rec_file = 'G56_stim.txt';
%rec_file = 'tmp_tmp.txt';
%rec_file = 'ponsvglut_stim.txt';
%rec_file = 'vlpag-pons_stim.txt';
% rec_file = 'NTS_ChR2_2min.txt';

rec_file = 'NTS_eYFP.txt';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Parameters to choose %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
psave = 0;
% parameter for fine time scale
down = 20;           
% large time bin for time-dependent markov computation
large_bin = 60;
% time preceding laser
pre = 300; 
% laser stimulation duration
laser_tend = 120;
% time following laser
post = laser_tend+pre;
% for baseline computation laser stimulation periods plus an additional
% offset ($after_laser) are excluded
after_laser = 60;
%%% pmarkov == 1, determine baseline using markov matrix
%%% pmarkov == 0, set baseline by averaging over "bars" outside of laser stimulation
pmarkov = 0;
%%% baseline and laser transition probability are calculate over the large
%%% bins (of duration $large_bin)
pbinavg = 1;
%%% condidence interval:
alpha = 0.05;
%%% number of bootstrap iterations
nboot = 1000;
%%% pchange == 1: if there's a tie in sleep state downsampling, then use
%%% the following hierachy: W>N>R
pchange = 1;


%%
%%% Load Recordings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen( fullfile(confpath, rec_file) );
s = fscanf(fid, '%c', inf);
fclose(fid); 
lines = regexp(s, '\n', 'split');

clear R; j=1;
for i=1:length(lines)
    l = lines{i};
    
    if regexp(l, '^#')
        continue;
    end
    
    if (isempty(l)>0) || ~isempty(regexp(l, '^\s'))
        newline = 1;
        continue;
    end
    a = regexp(l, '\s+', 'split');
    
    if (strcmp(a{1}, 'E') == 1)
        R(j).name = a{2};
        name = a{2};
        a = regexp(name, '_', 'split');
        R(j).idf = a{1};
        j = j+1;
    end
end

%%% set correct ppath
for i=1:length(R)
    if exist(fullfile(root, R(i).name), 'dir')
        ppath = root;
    else
        ppath = backup;
    end
    R(i).ppath = ppath;
end
%%% END[Load Recordings] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%
%%% build up large matrix containing are laser stimulation trials
MX = [];
for i=1:length(R)
    mx = whole_matrix(R(i).ppath, R(i).name,pre,post,down,pchange);
    MX = [MX; mx];
end


%%
%%% Markov Computation & Bootstrap 
%%% time axis:
t = -(pre):large_bin:(post-large_bin);
t = t+large_bin/2;

%%% indices during and outside laser stimulation
% indices of large bins during laser
ij = find(t>=0 & t<laser_tend); 
tmp = find(t>=0 & t<(laser_tend+after_laser));
% indices of large bins outsize laser (and $after_laser)
ii = setdiff(1:length(t), tmp); clear tmp;


%%% set seed 
rand('seed', iseed);

%%% initialize matrices
nrows = round(size(MX,1));
nseq = (pre+post) / large_bin;
M = cell(1,9);
for i=1:nboot
    M{i} = zeros(nboot, nseq);
end
Base = cell(1,9);
for i=1:nboot
    Base{i} = zeros(nboot, 1);
end
Laser = cell(1,9);
for i=1:nboot
    Laser{i} = zeros(nboot, 1);
end

%%% bootstrapping
for b=1:nboot
    %%% randomly draw $nrows trials from trial-matrix @MX
    idx = randi(nrows,[nrows,1]);
    %%% build markov matrix for each $large_bin using $down time steps:
    bMX = build_markov_matrix_seq(MX(idx,:), down, large_bin);
    if pbinavg == 0 %%% calculate baseline and laser transition prob. on fine time scale
        baseline = complete_transition_matrix_trials(MX(idx,:), down, pre, post, after_laser);
        laser    = complete_transition_matrix_trials(MX(idx,:), down, pre, post, after_laser, 1);
    end
    for si=1:3
        for sj=1:3
            id = (si-1)*3+sj;
            M{id}(b,:) = reshape(bMX(si,sj,:), [1, size(bMX,3)]);
            if pbinavg == 0
                Base{id}(b,:)  = baseline(si,sj);
                Laser{id}(b,:) = laser(si,sj);
            end
        end
    end 
end

%%% average over large $large_bin bins to get baseline and laser transition
%%% probabilities
if pbinavg == 1
    for si=1:3
        for sj=1:3
            id = (si-1)*3+sj;
            Laser{id} = mean(M{id}(:,ij),2);
            Base{id}  = mean(M{id}(:,ii),2);
        end
    end
end



%%
%%% plot nice figure
figure;
for si=1:3
    for sj=1:3
        id = (si-1)*3+sj;
        subplot(3,3,id); hold on;
        P = M{id};
        
        patch([0, laser_tend, laser_tend, 0], [0, 0, 1.05, 1.05], [0.6 0.6 1], 'EdgeColor', 'none');
        bar(t, nanmean(P), 'FaceColor', 'w');
        
        % get errorbars for time-dependent transition probabilities: "1-alpha" confidence interval;
        for i=1:size(P,2)
            P(:,i) = sort(P(:,i));
        end
        Bounds = zeros(2, size(P,2));
        Bounds(1,:) = -P(nboot*(alpha/2),:) + nanmean(P);
        Bounds(2,:) = P(end-nboot*(alpha/2),:) - nanmean(P);
        
        % get errorbars for baseline
        baseline = Base{id};
        baseline = sort(baseline);
        Bounds_baseline = zeros(1,2);
        Bounds_baseline(1) = -baseline(nboot*(alpha/2)) + nanmean(baseline);
        Bounds_baseline(2) =  baseline(end-nboot*(alpha/2)) - nanmean(baseline);
        

        %plot(t, ones(1,length(t))*CMX(si,sj), '--', 'Color', [1 0 0], 'LineWidth', 1);
        b = nanmean(baseline);
%         JackKnife(t, b*ones(1,length(t)), b+Bounds_baseline(1)*ones(1,length(t)), b-Bounds_baseline(2)*ones(1,length(t)), [1 0 0], [1 0.8 0.8]);
        plot(t, ones(1,length(t))*mean(baseline), '--', 'Color', [1 0 0], 'LineWidth', 1);
        
        H=errorbar(t, nanmean(P), Bounds(1,:), Bounds(2,:), '.', 'Color', 'k', 'LineWidth', 1);
        errorbar_tick(H,10000);
        
        
        dt = t(2)-t(1);
        xlim([t(1)-dt, t(end)+dt/2]);
        set(gca, 'FontSize', 12);
        set(gca, 'XTick', [0 laser_tend]);
        ylim([0 1]);
        
        %%% set title
        if si==1 && sj==1
            ylabel('REM');
            title('REM');
        end
        if si==1 && sj==2
            title('Wake');
        end
        if si==1 && sj==3
            title('NREM');
        end
        if si==2 && sj==1
            ylabel('Wake');
        end
        if si==3 && sj==1
            ylabel('NREM');
        end
        
        if si==3 && sj==1
            ylim([0, 0.2]);
        end
        
        if si==3 && sj==2
            ylim([0, 0.2]);
        end
        if si==3 && sj==3
            ylim([0.5, 1]);
        end
    end
end


if psave == 1
    file = fullfile(outpath, fig_name);
    print('-dpdf', file);
end


%%
%%% Some Statistics; "Paired Statistics"
mapping = [1 2 3; 4 5 6; 7 8 9];
State = {'REM ', 'Wake', 'NREM'};
fprintf('\n\n');
fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');
display('Paired Statistics:');
Mod = zeros(3,3);
for si=1:3
    for sj=1:3
        P = M{mapping(si,sj)};
        
        %%% probabilities during laser stimulation
        %laser = mean(P(:,ij),2);
        laser = Laser{mapping(si,sj)};
        
        %%% probabilities outside laser stimulation
        %basel = mean(P(:,ii),2);
        basel = Base{mapping(si,sj)};
        
        D = laser-basel;
        p = length(find(D>=0)) / length(D);
        Mod(si,sj) = nanmean(laser)/nanmean(basel);
        
        s = '=';      
        if Mod(si,sj) > 1
            %%% there's an increase in the transition probability during
            %%% laser, i.e. more diff values should be larger than zero
            val = 1-p;
            if val == 1
                s = '>';
                val = 1-1/nboot;
            end
            if val == 0
                s = '<';
                val = 1/nboot;
            end
            if val<alpha
                fprintf('%s -> %s: Trans. prob. is INCREASED by a factor of %.3f; P %s %.4f\n', State{si}, State{sj}, Mod(si,sj), s, val);
            else
                fprintf('%s -> %s: Trans. prob. is increased by a factor of %.3f; P %s %.4f\n', State{si}, State{sj}, Mod(si,sj), s, val);
            end
        else
            val = p;
            if val == 1
                s = '>';
                val = 1-1/nboot;
            end
            if val == 0
                s = '<';
                val = 1/nboot;
            end
            if val < alpha
                fprintf('%s -> %s: Trans. prob. is DECREASED by a factor of %.3f; P %s %.4f\n', State{si}, State{sj}, Mod(si,sj), s, val);
            else
                fprintf('%s -> %s: Trans. prob. is decreased by a factor of %.3f; P %s %.4f\n', State{si}, State{sj}, Mod(si,sj), s, val);
            end
        end
    end
end



%%
%%% Some Statistics; "Unpaired Statistics"
fprintf('\n\n');
fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');
display('Unpaired Statistics:');
Mod = zeros(3,3);
for si=1:3
    for sj=1:3
        P = M{mapping(si,sj)};
        
        %%% probabilities during laser stimulation
        laser = Laser{mapping(si,sj)};
        %%% probabilities outside laser stimulation
        basel = Base{mapping(si,sj)};
        %%% sort to get confidence intervals
        laser = sort(laser);
        basel = sort(basel);
        
        psig = 0;
        %%% baseline is smaller than laser
        if mean(basel) < mean(laser)
            sig_basel = basel(end-nboot*(alpha/2));
            sig_laser = laser(nboot*(alpha/2));
            
            if sig_basel < sig_laser
                psig = 1;
            end 
        end
        
        %%% baseline is larger than laser
        if mean(basel) > mean(laser)
            sig_basel = basel(nboot*(alpha/2));
            sig_laser = laser(end-nboot*(alpha/2));
            
            if sig_basel > sig_laser
                psig = 1;
            end 
        end
        
        Mod(si,sj) = nanmean(laser)/nanmean(basel);
        if Mod(si,sj) > 1
            if psig == 1;
                fprintf('%s -> %s: Trans. prob. is INCREASED by a factor of %.3f; P > 0.05\n', State{si}, State{sj}, Mod(si,sj));            
            else
                fprintf('%s -> %s: Trans. prob. is increased by a factor of %.3f; P < 0.05\n', State{si}, State{sj}, Mod(si,sj));            
            end
        else
            if psig == 1;
                fprintf('%s -> %s: Trans. prob. is DECREASED by a factor of %.3f; P > 0.05\n', State{si}, State{sj}, Mod(si,sj));            
            else
                fprintf('%s -> %s: Trans. prob. is decreased by a factor of %.3f; P < 0.05\n', State{si}, State{sj}, Mod(si,sj));            
            end
            
        end

    end
end








