function [pMX, MX, C, t] = transition_count(ppath, name)
% [pMX, MX, C] = transition_count(ppath, name)
% @Return:
% 3 dim. Matrix. The i-th row and j-th column describes the probablity of a
% switch from state i to state j. 
% 
% The 3rd dimension is time
%
% @pMX      -       conditional maxtrix, the columns of each 2 dim. matrix
%                   sum up to 1
% @MX       -       pure count of transitions
% @C        -       2D matrix; C(i,t_k) describes how often state i appeared
%                   at timepoint t_k
% @t        -       time axis
% Some thoughts on TIME:
% times goes from -$pre to $post, so there are $pre+$post+1 time bins
% a transitions goes from time $i to $i+1; I think the best timing is
% -$pre+dt/2, (-$pre+1)+dt/2, ...
%
%

SR = 1525.88;
ds = 11;
pre = 600;
post = 720;
dt = (1/SR)*(round(SR)*5/2)*ds;  % number of downsampled time step
nbins = (round(SR)*5/2)*ds;   
ipre = round(pre/dt);
ipost = round(post/dt);

file = fullfile(ppath, name, ['remidx_' name '.txt']);
if ~exist(file, 'file')
    display([name ': no state file']);
    [M,S]=sleep_state5(ppath, name);
else
    [M,S] = load_stateidx(ppath, name);
end
M = downsample_states(M, ds);

%%% load laser signal
ddir = fullfile(ppath, name);
A = load(fullfile(ddir, ['laser_' name '.mat']));
idx_lsr = laser_start_end(A.laser, SR);
%%% downsample laser signal
for i=1:size(idx_lsr,1)
    idx_lsr(i,:) = floor(idx_lsr(i,:)./nbins);
end

nseq = ipre+ipost+1 -1; % "-1" because we look at transitions
MX = zeros(3,3, nseq);
C = zeros(3, nseq);
for i=2:size(idx_lsr,1)-1
    seq = M(idx_lsr(i,1)-ipre:idx_lsr(i,1)+ipost);
    for j=1:length(seq)-1
        MX(seq(j),seq(j+1),j) = MX(seq(j),seq(j+1),j)+1;
        C(seq(j),j) = C(seq(j),j)+1;
    end
end

pMX = MX;
for j=1:length(-ipre:ipost)-1
    for s=1:3
        pMX(s,:,j) = pMX(s,:,j) ./ C(s,j);
    end
end
t = -pre+dt/2:dt:post;
t = t(1:nseq);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mds = downsample_states(M, nbin)
n = floor(length(M) / nbin);
Mds = zeros(n,1);
for i=1:n
    m = M((i-1)*nbin+1:i*nbin);
    S = zeros(1,3);
    for s=1:3
        S(s) = length(find(m==s));
    end
    [~,ii] = max(S);
    Mds(i) = ii;
end






