% Firing rate during different states
%Shuming An 053121
% compatible with matlab 2017

total_len_rem = length(rem_time);
p=1;
rem_select_time(1) = rem_time(1);
for i= 2: total_len_rem
    if rem_time(i)-rem_time(i-1)>2
        p=p+1;
         rem_select_time(p)= rem_time(i-1);
         p=p+1;
        rem_select_time(p)= rem_time(i);
    end
end
 rem_select_time(p+1)= rem_time(total_len_rem);
 
 % select the on and off of sws
total_len_sws = length(sws_time);
p=1;
sws_select_time(1) = sws_time(1);
for i= 2: total_len_sws
    if sws_time(i)-sws_time(i-1)>2
        p=p+1;
         sws_select_time(p)= sws_time(i-1);
         p=p+1;
        sws_select_time(p)= sws_time(i);
    end
end
 sws_select_time(p+1)= sws_time(total_len_sws);
 
 % select the on and off of wake
total_len_wake = length(wake_time);
p=1;
wake_select_time(1) = wake_time(1);
for i= 2: total_len_wake
    if wake_time(i)-wake_time(i-1)>2
        p=p+1;
         wake_select_time(p)= wake_time(i-1);
         p=p+1;
        wake_select_time(p)= wake_time(i);
    end
end
 wake_select_time(p+1)= wake_time(total_len_wake);
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % count the the spikes number at different states
 % ??????????????????
 rem_spike = 0;
 sws_spike = 0;
 wake_spike = 0;
 
 ch_1 = SPKC8a_corerected;
%  SPKC12a_corerected = ch_1;
%  SPKC08a_corerected = ch_1*24414/24414.0625;
  i=1;
for ii = 1:2:(numel(rem_select_time)-1) 
    while ( ch_1(i) < rem_select_time (ii)*5 && i < numel(ch_1))% to check the every elment in ch1.
        i = i+1;
    end
        
while (ch_1(i)> rem_select_time (ii)*5 && ch_1(i)< rem_select_time (ii+1)*5 && i < numel(ch_1))% caculate from several data base, then make average.
    rem_spike = rem_spike+1;
    i = i+1;
   end
end
% select spikes in sws state
i=1;
for j = 1:2:(numel(sws_select_time)-1)
    while (ch_1(i) < sws_select_time (j)*5 && i < numel(ch_1)) % to check the every elment in ch1.
        i = i+1;
    end
while (ch_1(i)> sws_select_time (j)*5 && ch_1(i)< sws_select_time (j+1)*5 && i < numel(ch_1))% caculate from several data base, then make average.
    sws_spike = sws_spike+1;
    i = i+1;
   
end
end


% select spikes in wake state
i=1;
for k = 1:2:(numel(wake_select_time)-1)    
     while (ch_1(i) < wake_select_time (k)*5 && i < numel(ch_1)) % to check the every elment in ch1.
        i = i+1;
    end
       
while (ch_1(i)> wake_select_time (k)*5 && ch_1(i)< wake_select_time (k+1)*5 && i < numel(ch_1))% caculate from several data base, then make average.
    wake_spike = wake_spike+1;
    i = i+1;
end
end

rem_rate= rem_spike/(numel(rem_time)*5);
wake_rate= wake_spike/(numel(wake_time)*5);
sws_rate= sws_spike/(numel(sws_time)*5);
y_value = (rem_rate-sws_rate)/(rem_rate+sws_rate);
x_value = (wake_rate-sws_rate)/(wake_rate+sws_rate);
new_x_value = (sws_rate-wake_rate)/(wake_rate+sws_rate);
new_y_value = (rem_rate-wake_rate)/(rem_rate+wake_rate);

total_info = [numel(rem_time) numel(wake_time) numel(sws_time) rem_spike wake_spike sws_spike rem_rate wake_rate sws_rate x_value y_value new_x_value new_y_value];
    assignin('base','total_infomation',total_info);
    
    
    