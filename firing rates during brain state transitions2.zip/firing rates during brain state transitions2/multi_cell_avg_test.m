
% collect data from many neurons and average them
% zeke barger 082817
% select recordings by holding control and clicking each one, then click ok
function [] = multi_cell_avg_test()

q = input('W-N & N-W, R-W & W-R, or all-N & N-all? Type w, r, or a: ','s');

[FileNames,fpath,~] = uigetfile('*','Hold control and click all recordings',...
    'MultiSelect','on');
if ~iscell(FileNames) && ~isstr(FileNames) % nothing chosen
    disp('quitting');
    dirname = [];
    return
end
if ~iscell(FileNames)
    numselected = 1;
else
    numselected = max(size(FileNames)); % count selections
end

data = {};

for i = 1:numselected % for each file
    if ~iscell(FileNames)
        f=load([fpath,FileNames]); % load file
    else
        f=load([fpath,FileNames{i}]); % load file
    end
    fields = fieldnames(f); % get names of variables
    for j = 1:length(fields) % look through variables
        if strfind(fields{j},'corerected')
            data{end+1} = shuming_ed7test(getfield(f,fields{j}),f.eeg_power,f.EMG,...
                f.emg_power,f.rem_time,f.wake_time,f.sws_time,0,q);
        end
    end
end

n = length(data);

%% package data nicely
on_emg = [];
off_emg = [];
on_spk = [];
off_spk = [];
on_spect = [];
off_spect = [];
on_spect_m = [];
off_spect_m = [];
on_eeg_x = [];
off_eeg_x = [];
on_spk_x = [];
off_spk_x = [];
eeg_y = [];
emg_y = [];

% this is a kludge
oeal = [];
for i = 1:n
    oeal(i) = length(data{i}.on_emg_avg);
end
oeal_target = mode(oeal);
for i = 1:n
    if length(data{i}.on_emg_avg) ~= oeal_target
        temp = data{i}.on_emg_avg;
        data{i}.on_emg_avg = zeros(1,oeal_target);
        data{i}.on_emg_avg(1:length(temp)) = temp;
    end
end

onn = 0;
offn = 0;



for i = 1:n
    if length(data{i}.on_spk_x) > 1 % has onsets
        choice = 'y';
        lp = 0;
        if i > 1 && abs(length(data{i}.off_emg_avg) - size(off_emg,2)) > 1
            disp(['possible length problem on cell ',num2str(i)])
            choice = input('Continue? y/n: ','s');
            lp = 1;
        end
        if strcmpi(choice,'y')
            
            
            
            on_emg(end+1,1:length(data{i}.on_emg_avg)) = data{i}.on_emg_avg;
            on_spk(end+1,1:length(data{i}.on_spk_avg)) = data{i}.on_spk_avg;
            on_spect(1:size(data{i}.on_spect_avg,1),1:size(data{i}.on_spect_avg,2),...
                end+1) = data{i}.on_spect_avg;
            on_spect_m(1:size(data{i}.on_spect_m_avg,1),1:size(data{i}.on_spect_m_avg,2),...
                end+1) = data{i}.on_spect_m_avg;
            
            onn = onn + data{i}.onn;
            
            
            % kludge
            % get axes
            if ~lp
                on_spk_x = data{i}.on_spk_x;
                eeg_y = data{i}.eeg_y;
                on_eeg_x = data{i}.on_eeg_x;
                emg_y = data{i}.emg_y;
            end
        end
    end
    if length(data{i}.off_spk_x) > 1 % has offsets
        choice = 'y';
        lp = 0;
        if i > 1 && abs(length(data{i}.off_emg_avg) - size(off_emg,2)) > 1
            disp(['possible length problem on cell ',num2str(i)])
            choice = input('Continue? y/n: ','s');
            lp = 1;
        end
        if strcmpi(choice,'y')
            
            
            off_emg(end+1,1:length(data{i}.off_emg_avg)) = data{i}.off_emg_avg;
            off_spk(end+1,1:length(data{i}.off_spk_avg)) = data{i}.off_spk_avg;
            off_spect(1:size(data{i}.off_spect_avg,1),1:size(data{i}.off_spect_avg,2),...
                end+1) = data{i}.off_spect_avg;
            off_spect_m(1:size(data{i}.off_spect_m_avg,1),1:size(data{i}.off_spect_m_avg,2),...
                end+1) = data{i}.off_spect_m_avg;
            offn = offn + data{i}.offn;
            
            if ~lp
                off_spk_x = data{i}.off_spk_x;
                off_eeg_x = data{i}.off_eeg_x;
                eeg_y = data{i}.eeg_y;
                emg_y = data{i}.emg_y;
            end
            
        end
    end
end

% first sheet is 0s...
on_spect(:,:,1) = [];
off_spect(:,:,1) = [];
on_spect_m(:,:,1) = [];
off_spect_m(:,:,1) = [];

on_spect_avg = mean(on_spect,3);
on_emg_avg = mean(on_emg,1);
on_spk_avg = mean(on_spk,1);
on_spect_m_avg = mean(on_spect_m,3);
off_spect_avg = mean(off_spect,3);
off_emg_avg = mean(off_emg,1);
off_spk_avg = mean(off_spk,1);
off_spect_m_avg = mean(off_spect_m,3);


%% make plots
switch q
    case 'w'
        txt = 'Wake';
    case 'r'
        txt = 'REM';
    case 'a'
        txt = 'W&R';
end


% s.e.m. for each measurement
if size(on_emg,1) > 1
    on_spk_sem = std(on_spk,1)/sqrt(size(on_spk,1));
    on_emg_sem = std(on_emg)/sqrt(size(on_emg,1));
else
    on_spk_sem = zeros(1,length((on_spk)));
    on_emg_sem = zeros(1,length((on_emg)));
end

if size(off_emg,1) > 1 
    off_spk_sem = std(off_spk)/sqrt(size(off_spk,1));
    off_emg_sem = std(off_emg)/sqrt(size(off_emg,1));
else
    off_spk_sem = zeros(1,length((off_spk)));
    off_emg_sem = zeros(1,length((off_emg)));
end

figure
sp1=subplot(4,2,1);
imagesc(on_eeg_x,eeg_y,on_spect_avg)
assignin('base', 'on_spect_avg', on_spect_avg);
axis xy
ylabel('EEG freq (hz)')
set(gca,'XTickLabel',[])
title([txt, ' to NREM (',num2str(onn),')'])

sp3=subplot(4,2,3);
imagesc(on_eeg_x,emg_y,on_spect_m_avg)
axis xy
ylabel('EMG freq (hz)')
set(gca,'XTickLabel',[])


sp5=subplot(4,2,5);

fill([1:length(on_emg_sem),length(on_emg_sem):-1:1],...
    [on_emg_sem+on_emg_avg, fliplr(on_emg_avg-on_emg_sem)],...
    'k','FaceAlpha',.3,'EdgeColor','none')
hold on, plot(on_emg_avg,'k')
ylabel('EMG')
set(gca,'XTickLabel',[])
axis tight

sp7=subplot(4,2,7);

fill([on_spk_x,fliplr(on_spk_x)],[on_spk_sem+on_spk_avg,...
    fliplr(on_spk_avg-on_spk_sem)],'b','FaceAlpha',.3,'EdgeColor','none')
hold on, plot(on_spk_x,on_spk_avg,'b')
ylabel('spikes/s')
axis tight
xlabel('Time (s)')

% offset


% figure
sp2=subplot(4,2,2);
imagesc(off_eeg_x,eeg_y,off_spect_avg)
assignin('base', 'off_spect_avg', off_spect_avg);
axis xy
ylabel('EEG freq (hz)')
set(gca,'XTickLabel',[])
title(['NREM to ', txt, ' (',num2str(offn),')'])

sp4=subplot(4,2,4);
imagesc(off_eeg_x,emg_y,off_spect_m_avg)
assignin('base', 'off_spect_m_avg', off_spect_m_avg);
axis xy
ylabel('EMG freq (hz)')
set(gca,'XTickLabel',[])


sp6=subplot(4,2,6);

fill([1:length(off_emg_sem),length(off_emg_sem):-1:1],...
    [off_emg_sem+off_emg_avg, fliplr(off_emg_avg-off_emg_sem)],...
    'k','FaceAlpha',.3,'EdgeColor','none')
hold on, plot(off_emg_avg,'k')
ylabel('EMG')
set(gca,'XTickLabel',[])
axis tight

sp8=subplot(4,2,8);

fill([off_spk_x,fliplr(off_spk_x)],[off_spk_sem+off_spk_avg,...
    fliplr(off_spk_avg-off_spk_sem)],'b','FaceAlpha',.3,'EdgeColor','none')
hold on, plot(off_spk_x,off_spk_avg,'b')
ylabel('spikes/s')
axis tight
xlabel('Time (s)')

% match axis ranges
linkaxes([sp5,sp6],'y');
linkaxes([sp7,sp8],'y');
axes(sp1);
clim1 = caxis;
set(sp2,'Clim',clim1);

