% zeke barger 082817
% plots eeg spectrogram, emg amplitude, and firing rate relative to NREM
% onset and offset
% similar to extended data figure 7 in franz's paper

function [output] = shuming_ed7test(spike_times,eeg_power,EMG,emg_power,...
    rem_time,wake_time,sws_time, plots, state2)

%% parameters
% thresholds: how long should the mouse be in a brain state? units: seconds
% ideally a multiple of state_bin
on_before_thr = 40;
on_after_thr = 40;
off_before_thr = 40;
off_after_thr = 40;


% spike_times = Channel12a_corerected1; % variable name of spike times
hz = 1500; % eeg and emg sampling frequency
on_before = 30; % seconds before NREM onset
on_after = 30; % seconds after NREM onset
off_before = 30; % seconds before NREM offset
off_after = 30; % seconds after NREM offset
spike_bin = 5; % bin width for spike counts
emg_bin = .5; % bin width for emg amplitude
state_bin = 5; % state classification bin width in seconds

% don't edit these (thresholds in different units)
onbt = on_before_thr / state_bin;
onat = on_after_thr / state_bin;
offbt = off_before_thr / state_bin;
offat = off_after_thr / state_bin;

%% other state besides nrem to analyze
s1 = 3; % nrem%%%�ǳ���Ҫ����3����NREM����1����REM��
if strcmpi(state2,'w')
    s2 = 2;
else
    if strcmpi(state2,'r')
        s2 = 1;
    else
        if strcmpi(state2,'a')
        	s2 = 0;
        end
    end
end

%%
emg_abs = abs(EMG)'; % get absolute value of emg
emg_w = round(emg_bin * hz); % get usable bin width
emg_abs = emg_abs(1:(floor(length(emg_abs)/emg_w)*emg_w)); % make emg divisible
emg_len = length(emg_abs) / hz; % get emg length in seconds
emg_mat = reshape(emg_abs,[emg_w,length(emg_abs)/emg_w]); % each column is a bin
emg_amp = mean(emg_mat); % get average of each bin
emg_t = (1:length(emg_amp))*emg_w/hz - .5*emg_w/hz; % get time axis for binned emg

spike_t = (0:spike_bin:(max(spike_times)+60)) + .5*spike_bin; % time axis for binned spks

[spkcts,~] = hist(spike_times,spike_t); % bin the spikes
spkcts = spkcts / spike_bin; % set to spikes/sec

%%
state = zeros(1,max([sws_time; wake_time; rem_time]));
for i = 1:length(state)
    if find(rem_time==i)
        state(i) = 1;
    else
        if find(wake_time == i)
            state(i) = 2;
        else
            if find(sws_time == i)
                state(i) = 3;
            end
        end
    end
end
if s2 > 0
    on_seq = [ones(1,onbt)*s2, ones(1,onat)*s1];
    off_seq = [ones(1,offbt)*s1, ones(1,offat)*s2];
    
    on_idx = strfind(state, on_seq)+onbt; % onsets
    off_idx = strfind(state, off_seq)+offbt-1; % offsets
else
    on_seq1 = [ones(1,onbt)*1, ones(1,onat)*s1];
    off_seq1 = [ones(1,offbt)*s1, ones(1,offat)*1];
    on_seq2 = [ones(1,onbt)*2, ones(1,onat)*s1];
    off_seq2 = [ones(1,offbt)*s1, ones(1,offat)*2];
    
    on_idx = sort([strfind(state, on_seq1)+onbt, strfind(state, on_seq2)+onbt]); % onsets
    off_idx = sort([strfind(state, off_seq1)+offbt-1, strfind(state, off_seq2)+offbt-1]); % offsets
end
% on_idx = sws_time(find(diff(sws_time)-1)+1); % indices of NREM onsets
% off_idx = sws_time(find(diff(sws_time)-1)); % indices of NREM offsets

%%
spect_t = 1:size(eeg_power,2); % spectrogram time axis, if it's 1 sec / bin
state_t = (1:max([sws_time;rem_time;wake_time]))*state_bin-.5*state_bin; % state time ax

on_times = state_t(on_idx) - .5*state_bin; % nrem onsets in sec
off_times = state_t(off_idx) + .5*state_bin; % nrem offsets in sec

% remove bad idx
on_times(on_times < 1.1*on_before) = [];
off_times((max(state_t) - off_times) < 1.1*off_after) = [];

if ~isempty(intersect(on_times,off_times)) 
    disp('times overlap')
end
if ~isempty(intersect(on_idx, off_idx))
    disp('idx overlap')
end

% set up containers for time-locked data
on_spk = [];
off_spk = [];
on_spect = [];
off_spect = [];
on_emg = [];
off_emg = [];

on_spect_m = [];
off_spect_m = [];

for i = 1:length(on_times) % get onset data
    t_b = on_times(i) - on_before; % time in sec before nrem onset
    t_a = on_times(i) + on_after; % time in sec after nrem onset
    [~,spk_b] = min(abs(spike_t - t_b)); % closest timepoint to start
    [~,spk_a] = min(abs(spike_t - t_a)); % closest timepoint to end
    try
        on_spk(end+1,:) = spkcts(spk_b:spk_a); % get datapoints between start and end
    catch % number of datapoints was (slightly) different
        on_spk(end+1,:) = spkcts(spk_b:(spk_b-1+size(on_spk,2)));
    end
    
    [~,spect_b] = min(abs(spect_t - t_b));
    [~,spect_a] = min(abs(spect_t - t_a));
    try
        on_spect(:,:,end+1) = eeg_power(:,spect_b:spect_a);
    catch
        on_spect(:,:,end+1) = eeg_power(:,spect_b:(spect_b-1+size(on_spect,2)));
    end
    
    try
        on_spect_m(:,:,end+1) = emg_power(:,spect_b:spect_a);
    catch
        on_spect_m(:,:,end+1) = emg_power(:,spect_b:(spect_b-1+size(on_spect_m,2)));
    end
    
    [~,emg_b] = min(abs(emg_t - t_b));
    [~,emg_a] = min(abs(emg_t - t_a));
    try
        on_emg(end+1,:) = emg_amp(emg_b:emg_a);
    catch
        on_emg(end+1,:) = emg_amp(emg_b:(emg_b-1+size(on_emg,2)));
%         disp(num2str(abs(size(on_emg,2) - length(emg_b:emg_a))))
    end
end

for i = 1:length(off_times)
    t_b = off_times(i) - off_before;
    t_a = off_times(i) + off_after;
    [~,spk_b] = min(abs(spike_t - t_b));
    [~,spk_a] = min(abs(spike_t - t_a));
    try
        off_spk(end+1,:) = spkcts(spk_b:spk_a);
    catch
        off_spk(end+1,:) = spkcts(spk_b:(spk_b-1+size(off_spk,2)));
    end
    
    [~,spect_b] = min(abs(spect_t - t_b));
    [~,spect_a] = min(abs(spect_t - t_a));
    
%     if spect_b-1+size(off_spect,2) <= size(eeg_power,2)
        try
            off_spect(:,:,end+1) = eeg_power(:,spect_b:spect_a);
        catch
            off_spect(:,:,end+1) = eeg_power(:,spect_b:(spect_b-1+size(off_spect,2)));
        end
        
        try
            off_spect_m(:,:,end+1) = emg_power(:,spect_b:spect_a);
        catch
            off_spect_m(:,:,end+1) = emg_power(:,spect_b:(spect_b-1+size(off_spect_m,2)));
        end
%     end
    
    [~,emg_b] = min(abs(emg_t - t_b));
    [~,emg_a] = min(abs(emg_t - t_a));
%     if emg_b-1+size(off_emg,2) < length(emg_amp)
        try
            off_emg(end+1,:) = emg_amp(emg_b:emg_a);
        catch
            off_emg(end+1,:) = emg_amp(emg_b:(emg_b-1+size(off_emg,2)));
%             disp(num2str(abs(size(off_emg,2) - length(emg_b:emg_a))))
        end
%     end
end

% s.e.m. for each measurement
if length(on_times) > 1
    on_spk_sem = std(on_spk)/sqrt(length(on_times));
    on_emg_sem = std(on_emg)/sqrt(length(on_times));
else
    on_spk_sem = zeros(1,length((on_spk)));
    on_emg_sem = zeros(1,length((on_emg)));
end

if length(off_times) > 1
    off_emg_sem = std(off_emg)/sqrt(length(off_times));
    off_spk_sem = std(off_spk)/sqrt(length(off_times));
else
    off_emg_sem = zeros(1,length((off_emg)));
    off_spk_sem = zeros(1,length((off_spk)));
end

% first sheet is 0s...
on_spect(:,:,1) = [];
off_spect(:,:,1) = [];
on_spect_m(:,:,1) = [];
off_spect_m(:,:,1) = [];

%% Generate plots


% onset

% calculate some x and y axis labels
on_spk_x = linspace(-1*on_before,on_after,length(mean(on_spk,1)));
eeg_y = linspace(1,25,size(on_spect,1));
emg_y = linspace(100,255,size(on_spect_m,1));
on_eeg_x = linspace(-1*on_before,on_after,size(on_spect,2));

on_spect_avg = mean(on_spect,3);
on_emg_avg = mean(on_emg,1);
on_spk_avg = mean(on_spk,1);
on_spect_m_avg = mean(on_spect_m,3);

off_spk_x = linspace(-1*off_before,off_after,length(mean(off_spk,1)));
off_eeg_x = linspace(-1*on_before,on_after,size(off_spect,2));
off_spect_avg = mean(off_spect,3);
off_emg_avg = mean(off_emg,1);
off_spk_avg = mean(off_spk,1);
off_spect_m_avg = mean(off_spect_m,3);

if plots
    
    figure
    sp1=subplot(4,2,1);
    imagesc(on_eeg_x,eeg_y,on_spect_avg)
    axis xy
    ylabel('EEG freq (hz)')
    set(gca,'XTickLabel',[])
    title('onset')
    
    sp3=subplot(4,2,3);
    imagesc(on_eeg_x,emg_y,on_spect_m_avg)
    axis xy
    ylabel('EMG freq (hz)')
    set(gca,'XTickLabel',[])
    
    
    sp5=subplot(4,2,5);
    
    fill([1:length(on_emg_sem),length(on_emg_sem):-1:1],...
        [on_emg_sem+on_emg_avg, fliplr(on_emg_avg-on_emg_sem)],...
        'k','FaceAlpha',.3,'EdgeColor','none')
    hold on, plot(on_emg_avg,'k')
    ylabel('EMG')
    set(gca,'XTickLabel',[])
    axis tight
    
    sp7=subplot(4,2,7);
    
    fill([on_spk_x,fliplr(on_spk_x)],[on_spk_sem+on_spk_avg,...
        fliplr(on_spk_avg-on_spk_sem)],'b','FaceAlpha',.3,'EdgeColor','none')
    hold on, plot(on_spk_x,on_spk_avg,'b')
    ylabel('spikes/s')
    axis tight
    xlabel('Time (s)')
    
    % offset
    
    
    % figure
    sp2=subplot(4,2,2);
    imagesc(off_eeg_x,eeg_y,off_spect_avg)
    axis xy
    ylabel('EEG freq (hz)')
    set(gca,'XTickLabel',[])
    title('offset')
    
    sp4=subplot(4,2,4);
    imagesc(off_eeg_x,emg_y,off_spect_m_avg)
    axis xy
    ylabel('EMG freq (hz)')
    set(gca,'XTickLabel',[])
    
    
    sp6=subplot(4,2,6);
    
    fill([1:length(off_emg_sem),length(off_emg_sem):-1:1],...
        [off_emg_sem+off_emg_avg, fliplr(off_emg_avg-off_emg_sem)],...
        'k','FaceAlpha',.3,'EdgeColor','none')
    hold on, plot(off_emg_avg,'k')
    ylabel('EMG')
    set(gca,'XTickLabel',[])
    axis tight
    
    sp8=subplot(4,2,8);
    
    fill([off_spk_x,fliplr(off_spk_x)],[off_spk_sem+off_spk_avg,...
        fliplr(off_spk_avg-off_spk_sem)],'b','FaceAlpha',.3,'EdgeColor','none')
    hold on, plot(off_spk_x,off_spk_avg,'b')
    ylabel('spikes/s')
    axis tight
    xlabel('Time (s)')
    
    % match axis ranges
    linkaxes([sp5,sp6],'y');
    linkaxes([sp7,sp8],'y');
    axes(sp1);
    clim1 = caxis;
    set(sp2,'Clim',clim1);
    
end

output = struct;
output.eeg_y = eeg_y;
output.on_eeg_x = on_eeg_x;
output.off_eeg_x = off_eeg_x;
output.on_spk_x = on_spk_x;
output.off_spk_x = off_spk_x;
output.on_spect_avg = on_spect_avg;
output.on_emg_avg = on_emg_avg;
output.on_spk_avg = on_spk_avg;
output.off_spect_avg = off_spect_avg;
output.off_emg_avg = off_emg_avg;
output.off_spk_avg = off_spk_avg;

output.emg_y = emg_y;
output.on_spect_m_avg = on_spect_m_avg;
output.off_spect_m_avg = off_spect_m_avg;
output.onn = length(on_times);
output.offn = length(off_times);

% disp([num2str(length(on_times)),' ',num2str(length(off_times))])