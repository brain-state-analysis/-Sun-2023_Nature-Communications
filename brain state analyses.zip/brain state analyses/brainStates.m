
function varargout = brainStates(varargin)
% BRAINSTATES M-file for brainStates.fig
%      BRAINSTATES, by itself, creates a new BRAINSTATES or raises the existing
%      singleton*.
%
%      H = BRAINSTATES returns the handle to a new BRAINSTATES or the handle to
%      the existing singleton*.
%
%      BRAINSTATES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BRAINSTATES.M with the given input arguments.
%
%      BRAINSTATES('Property','Value',...) creates a new BRAINSTATES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before brainStates_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to brainStates_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help brainStates

% Last Modified by GUIDE v2.5 17-Dec-2015 22:49:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @brainStates_OpeningFcn, ...
                   'gui_OutputFcn',  @brainStates_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before brainStates is made visible.
function brainStates_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to brainStates (see VARARGIN)

% Choose default command line output for brainStates
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes brainStates wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = brainStates_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in selelctWake.
function selelctWake_Callback(hObject, eventdata, handles)
% hObject    handle to selelctWake (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selelctWake


% --- Executes on button press in selectSWS.
function selectSWS_Callback(hObject, eventdata, handles)
% hObject    handle to selectSWS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selectSWS


% --- Executes on button press in selectREM.
function selectREM_Callback(hObject, eventdata, handles)
% hObject    handle to selectREM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selectREM


% --- Executes on button press in selectMethod.
function selectMethod_Callback(hObject, eventdata, handles)
% hObject    handle to selectMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selectMethod


% --- Executes on button press in loadFile.
function loadFile_Callback(hObject, eventdata, handles)
% hObject    handle to loadFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% load base variable first
try
    try
        % try format 1
        eeg = evalin('base','eeg');
        emg = evalin('base','emg');
        LasT = evalin('base','LasT');
    catch
        % try format 2
        eeg = evalin('base','recordingFile.eeg');
        emg = evalin('base','recordingFile.emg');
        LasT = evalin('base','recordingFile.LasT');
    end
    recordingFile.filename = 'base';
    recordingFile.filepath = 'workspace/';
    set(handles.saveFolder,'userdata',pwd);
catch
    %% open file
    [filename,pathname] = uigetfile('*.mat','Select Recording');
    if filename == 0
        return
    end
    set(handles.fileName,'string',filename(3:end-4));
    set(handles.saveFolder,'userdata',pathname);
    load(horzcat(pathname,filename));
    recordingFile.filename = filename;
    recordingFile.filepath = pathname;
end
%% save file info
try
    % file format 1
    size(recordingFile.eeg)
    set(handles.loadFile,'userdata',recordingFile); 
catch
    try
        % file format 2
        recordingFile.eeg = eeg;
        recordingFile.emg = emg;
        recordingFile.LasT = LasT;
        set(handles.loadFile,'userdata',recordingFile);        
    catch 
        % error
     msgbox('Error in Open File!', 'Open File')
    end
end
%% process recordings
set(handles.processRecording,'value',1);
processRecording_Callback(hObject, eventdata, handles);

% --- Executes on button press in saveFile.
function saveFile_Callback(hObject, eventdata, handles)
% hObject    handle to saveFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

folder = get(handles.saveFolder,'userdata');
fn = get(handles.fileName,'string');
fn = horzcat(folder,'\',fn,'.mat')
recordingFile = get(handles.loadFile,'userdata');
fileSummary = get(handles.resultPlot2,'userdata');
save(fn,'recordingFile','fileSummary');
msgbox('File Saved','Save File');
% --- Executes on button press in togglebutton5.
function togglebutton5_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton5



function windowSize_Callback(hObject, eventdata, handles)
% hObject    handle to windowSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of windowSize as text
%        str2double(get(hObject,'String')) returns contents of windowSize as a double


% --- Executes during object creation, after setting all properties.
function windowSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to windowSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in displayResult.
function displayResult_Callback(hObject, eventdata, handles)
% hObject    handle to displayResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns displayResult contents as cell array
%        contents{get(hObject,'Value')} returns selected item from displayResult


% --- Executes during object creation, after setting all properties.
function displayResult_CreateFcn(hObject, eventdata, handles)
% hObject    handle to displayResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plotResult.
function plotResult_Callback(hObject, eventdata, handles)
% hObject    handle to plotResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plotResult


% --- Executes on button press in processRecording.
function processRecording_Callback(hObject, eventdata, handles)
% hObject    handle to processRecording (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% check button state
flag = get(handles.processRecording,'value');
if ~flag
    return;
end
%% load data and get process parameters
recordingFile = get(handles.loadFile,'userdata');
eeg = recordingFile.eeg;
emg = recordingFile.emg;
LasT = recordingFile.LasT(:,1);
windowSize = str2num(get(handles.windowSize,'string'));
sWindow = str2num(get(handles.sWindow,'string'));
%% process eeg/emg
recordingTime = size(eeg,2);
binNum = floor(recordingTime/windowSize);
LasT = LasT/windowSize;
x_time = 1:length(eeg);
%EEG 
%delta power 0.15~4
fN = size(eeg,1);
lb = round(0.15/(25/fN));
ub = round(4/(25/fN));
power_delta = sum(eeg(lb:ub,:));
%theta power 5-10
lb = round(5/(25/fN));
ub = round(10/(25/fN));
power_theta = sum(eeg(lb:ub,:));
R_theta_delta = power_theta ./ power_delta;
temp = reshape(R_theta_delta(1:binNum*windowSize),windowSize,binNum);
R_theta_delta = sum(temp,1);
R_theta_delta = conv(R_theta_delta,ones(1,sWindow)/sWindow, 'same');
power_EMG = sum(emg);
temp = reshape(power_EMG(1:binNum*windowSize),windowSize,binNum);
power_EMG = sum(temp,1);
power_EMG = conv(power_EMG,ones(1,sWindow)/sWindow, 'same');

%Laser
laserMask = zeros(size(eeg,2),1);
idx = find(diff(LasT)>1);
laserStart = vertcat(LasT(1),LasT(idx+1));
laserEnd = vertcat(LasT(idx),LasT(end));
%remove short laser
idx = find((laserEnd-laserStart)>5);
laserStart = laserStart(idx);
laserEnd = laserEnd(idx);
% plot eegspectrogram
F = floor(size(eeg,1)/25);
eeg_sumF = [];
nF = floor(size(eeg,1)/F);
for i = 1:nF
eeg_sumF(i,:) = sum(eeg(F*i-F+1:F*i,:),1);
end
eeg_sumFT = [];
T = windowSize;
nT = floor(size(eeg,2)/T);
for i = 1:nT
eeg_sumFT(:,i) = sum(eeg_sumF(:,T*i-T+1:T*i),2);
end
eeg_sumFT = flipud(eeg_sumFT);
%
maxEEG = max(max(eeg_sumFT));
% add laser maker
% for idx = 1:length(laserEnd)
%     eeg_sumFT(end,round(laserStart(idx)):round(laserEnd(idx)))= maxEEG/2;   
% end
axes = handles.eegSpectrogram;
imagesc(eeg_sumFT,'parent',axes);
assignin('base', 'eeg_sumFT', eeg_sumFT);
set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);

%%%%By shuming, make a new figure

%  figure(1);
%  axes = handles.eegSpectrogram;
% imagesc(eeg_sumFT,'parent',axes);
% set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
 % Plot EEG
% subplot(3)
%plot emg
% axes = handles.emgPlot;
% figEMG = plot(power_EMG,'parent',axes);
% set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
% hold(axes,'on')
% for idx = 1:length(laserEnd)
%     x = [laserStart(idx) laserStart(idx) laserEnd(idx) laserEnd(idx)];
%     y = [0 0.5*max(power_EMG) max(power_EMG) 0];
%     plot (x,y,'m','parent',axes)
% end
% hold(axes,'off')
% temp = axis(axes);
% axis(axes, [0 length(power_EMG) temp(3) temp(4)]);
% mod 09/27/2014
axes = handles.emgPlot;
power_EMG2 = power_EMG;
idx = find(power_EMG>10*mean(power_EMG));
power_EMG2(idx)= 10*mean(power_EMG);
figEMG = plot(power_EMG2,'parent',axes);
set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
hold(axes,'on')
for idx = 1:length(laserEnd)
    x = [laserStart(idx) laserStart(idx) laserEnd(idx) laserEnd(idx)];
    y = [0 0.5*max(power_EMG2) max(power_EMG2) 0];
    plot (x,y,'m','parent',axes)
end
hold(axes,'off')
temp = axis(axes);
axis(axes, [0 length(power_EMG) temp(3) temp(4)]);
%%%end mod
% plot eeg
axes = handles.eegPlot;
figEEG = plot(R_theta_delta,'parent',axes);
set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
hold(axes,'on')
for idx = 1:length(laserEnd)
    x = [laserStart(idx) laserStart(idx) laserEnd(idx) laserEnd(idx)];
    y = [0 0.5*max(R_theta_delta) max(R_theta_delta) 0];
    plot (x,y,'m','parent',axes)
end
hold(axes,'off')
temp = axis(axes);
axis(axes, [0 length(R_theta_delta) temp(3) temp(4)]);
% state space
X = [log(power_EMG);log(R_theta_delta)]';
axes = handles.stateSpacePlot;
scatter(X(:,1),X(:,2),30,'k.','parent',axes);
set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
%overlay with laser info
idxLaser = [];
for i = 1:length(laserEnd)
    idxLaser = horzcat(idxLaser,round(laserStart(i)):round(laserEnd(i)));
end
hold(axes,'on')
scatter(X(idxLaser,1),X(idxLaser,2),30,'b.','parent',axes);
hold(axes,'off')
%axis(axes, [0.8*min(X(:,1)) 1.2*max(X(:,1)) 0.8*min(X(:,2)) 1.2*max(X(:,2))]);
% % plot histogram
% temp = hist(log(power_EMG),[0.8*min(X(:,1)):0.1:1.2*max(X(:,1))]);
% bar([0.8*min(X(:,1)):0.1:1.2*max(X(:,1))],temp,'parent',handles.emgHistogram)
% axis(handles.emgHistogram, [0.8*min(X(:,1)) 1.2*max(X(:,1)) 0 max(temp)]);
% set(handles.emgHistogram,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0],'YDir','reverse')
% temp = hist(log(R_theta_delta),[0.8*min(X(:,2)):0.1:1.2*max(X(:,2))]);
% bar([0.8*min(X(:,2)):0.1:1.2*max(X(:,2))],temp,'parent',handles.eegHistogram)
% axis(handles.eegHistogram, [0 max(temp) 0.8*min(X(:,2)) 1.2*max(X(:,2)) ]);
% set(handles.eegHistogram,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0],'XDir','reverse')
%% process REM/Wake/SWS
for brainState = 1:3
    % update msg panel
    set(handles.infoPanel,'value',brainState);
    updateMsg(hObject, eventdata, handles);
    % select brain state
    [xs,ys] = ginput3(6);
    xv = [xs; xs(1)];
    yv = [ys; ys(1)];
    in = inpolygon(X(:,1),X(:,2),xv,yv);
    % cleaning up
    cbin = str2num(get(handles.fragmentSize,'string'));
    temp = conv(double(in),ones(1,cbin),'same')/cbin;
    idx = find(temp<0.5);
    in(idx)=0;
    idx = find(temp>0.5);
    in(idx)=1;
    idx = find(in==1);
    axes = handles.stateSpacePlot;
    %update eeg and emg figure
    switch brainState 
        case 1
            % REM
            inREM = in;
%             assignin('base', 'rem_in', inREM);
            assignin('base', 'rem_hightbox', in*3);
            hold(axes,'on')
            scatter(X(idx,1),X(idx,2),'r.','parent',axes)
            hold(axes,'off')
            lineWidth = 1.5;
            axes = handles.eegPlot;
            hightbox = in*mean(R_theta_delta);
            hold(axes,'on')
            plot(hightbox,'LineWidth',lineWidth,'color','r','parent',axes)
            plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
            hold(axes,'off')
            axes = handles.emgPlot;
            %select the  REM time valuble
%             Rem_in = in;
%             assignin('base', 'Rem_time_index', Rem_in);
            hightbox = in*mean(power_EMG);
            hold(axes,'on')
            plot(hightbox,'LineWidth',lineWidth,'color','r','parent',axes)
            plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
            hold(axes,'off')
            %mod 10/07/2014
            % mark REM in eeg spectragram
            axes = handles.eegSpectrogram;
            hold(axes,'on')
            idx = find(in);
            %select the  REM time point
            rem_idx = idx;
            rem_wtime = numel(rem_idx);
            assignin('base', 'rem_time', rem_idx);
            scatter(idx,ones(length(idx),1)*15,20,'r.','LineWidth',0.5,'parent',axes)
            hold(axes,'off')
            %end mod 10/07/2014
            % display summary
            trialLength = 600/windowSize; % show the whole window is 10 min.
            %bsSummmary = zeros(trialLength,length(laserEnd));
            for i = 1:length(laserEnd)
                 try
                    temp = in(round(laserStart(i)-48):(round(laserStart(i)-49)+trialLength))*3;        
                 catch
                     try
                         % end?
                        temp = in(round(laserStart(i)-48):end)*3;
                        temp(end:trialLength)=0;
                     catch
                         % start
                        temp = in(1:(round(laserStart(i)-49)+trialLength))*3;
                        temp = vertcat(zeros(trialLength-length(temp),1),temp);
                     end
                 end
                 bsSummmaryREM(:,i)=temp;
                 bsSummmaryREM2(:,i)=temp;
                 %start/end marker
                 bsSummmaryREM(48,i)=1;
                 bsSummmaryREM(round(48+laserEnd(i)-laserStart(i)),i)=2;
            end
            % plot the image above the line cure.
            axes = handles.resultPlot;
            im = imagesc(bsSummmaryREM','parent',axes);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
            %display summary2
            % Here just plot the line
            assignin('base', 'bsSummmaryREM', bsSummmaryREM);
            assignin('base', 'bsSummmaryREM2', bsSummmaryREM2);
            axes = handles.resultPlot2;
            im = plot(sum(bsSummmaryREM2,2),'parent',axes);
            temp = axis(axes);
            axis(axes, [0 trialLength temp(3) temp(4)]);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
        case 2
            % wake
            inWAK = in;
            assignin('base', 'wake_hightbox', in*2);
%             assignin('base', 'inWAK', inWAK);
            
            hold(axes,'on')
            scatter(X(idx,1),X(idx,2),'g.','parent',axes)
            hold(axes,'off')
            lineWidth = 1.5;
            axes = handles.eegPlot;
            %select the  Wake time valuble
%             wake_in = in;
%             assignin('base', 'wake_time_index', wake_in);
            hightbox = in*mean(R_theta_delta)*2;
            
            hold(axes,'on')
            plot(hightbox,'LineWidth',lineWidth,'color','g','parent',axes)
            plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
            hold(axes,'off')
            axes = handles.emgPlot;
            hightbox = in*mean(power_EMG)*1.5;
            hold(axes,'on')
            plot(hightbox,'LineWidth',lineWidth,'color','g','parent',axes)
            plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
            hold(axes,'off')
            %mod 10/07/2014
            % mark AWK in eeg spectragram
            axes = handles.eegSpectrogram;
            hold(axes,'on')
            idx = find(in);
            %select the  wake time point
            wake_idx = idx;
            wake_wtime = numel(wake_idx);
            assignin('base', 'wake_time', wake_idx);
            scatter(idx,ones(length(idx),1)*15,20,'y.','LineWidth',0.5,'parent',axes)
            hold(axes,'off')
            %end mod 10/07/2014
            % display summary
            trialLength = 600/windowSize;
            %bsSummmary = zeros(trialLength,length(laserEnd));
            for i = 1:length(laserEnd)
                 try
                    temp = in(round(laserStart(i)-48):(round(laserStart(i)-49)+trialLength))*3;        
                 catch
                     try
                         % end?
                        temp = in(round(laserStart(i)-48):end)*3;
                        temp(end:trialLength)=0;
                     catch
                         % start
                        temp = in(1:(round(laserStart(i)-49)+trialLength))*3;
                        temp = vertcat(zeros(trialLength-length(temp),1),temp);
                     end
                 end
                 bsSummmaryWAK(:,i)=temp;
                 bsSummmaryWAK2(:,i)=temp;
                 %start/end marker
                 bsSummmaryWAK(48,i)=1;
                 bsSummmaryWAK(round(48+laserEnd(i)-laserStart(i)),i)=2;
            end
            axes = handles.resultPlot3;
            im = imagesc(bsSummmaryWAK','parent',axes);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
            %display summary2
            axes = handles.resultPlot4;
            im = plot(sum(bsSummmaryWAK2,2),'parent',axes);
            temp = axis(axes);
            axis(axes, [0 trialLength temp(3) temp(4)]);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
        case 3
            % SWS
            % remove REM and WAK from SWS
            in = in & (~inREM) & (~inWAK);
            inSWS = in;
            assignin('base', 'SWS_hightbox', in*1);
%              assignin('base', 'SWS_in', inSWS);
             %select the  Wake time valuble
%             sws_in = in;
%             assignin('base', 'sws_time_index', sws_in);
            idx = find(in);
            %select the  wake time point
            sws_idx = idx;
            sws_wtime = numel(sws_idx);
            assignin('base', 'sws_time', sws_idx);
%             lineWidth = 1.5;
%             axes = handles.eegPlot;
%             hightbox = in*mean(R_theta_delta);
%             hold(axes,'on')
%             plot(hightbox,'LineWidth',lineWidth,'color','m','parent',axes)
%             plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
%             hold(axes,'off')
%             axes = handles.emgPlot;
%             hightbox = in*mean(power_EMG);
%             hold(axes,'on')
%             plot(hightbox,'LineWidth',lineWidth,'color','m','parent',axes)
%             plot(hightbox*0,'LineWidth',lineWidth,'color','k','parent',axes)
%             hold(axes,'off')
            % display summary
            trialLength = 600/windowSize;
            %bsSummmary = zeros(trialLength,length(laserEnd));
            for i = 1:length(laserEnd)
                 try
                    temp = in(round(laserStart(i)-48):(round(laserStart(i)-49)+trialLength))*3;        
                 catch
                     try
                         % end?
                        temp = in(round(laserStart(i)-48):end)*3;
                        temp(end:trialLength)=0;
                     catch
                         % start
                        temp = in(1:(round(laserStart(i)-49)+trialLength))*3;
                        temp = vertcat(zeros(trialLength-length(temp),1),temp);
                     end
                 end
                 bsSummmarySWS(:,i)=temp;
                 bsSummmarySWS2(:,i)=temp;
                 %start/end marker
                 bsSummmarySWS(48,i)=1;
                 bsSummmarySWS(round(48+laserEnd(i)-laserStart(i)),i)=2;
            end
            axes = handles.resultPlot5;
            im = imagesc(bsSummmarySWS','parent',axes);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
            %display summary2
            axes = handles.resultPlot6;
            im = plot(sum(bsSummmarySWS2,2),'parent',axes);
            temp = axis(axes);
            axis(axes, [0 trialLength temp(3) temp(4)]);
            set(axes,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    end
end
total_time=[rem_wtime wake_wtime sws_wtime];
    assignin('base','total_time',total_time);
%     figure (1)
%     plot(inREM);
%     figure (2)
%     plot(inWAK);
%     figure (3)
%     plot(inSWS);

% update msg panel
set(handles.infoPanel,'value',4);
updateMsg(hObject, eventdata, handles);

% calculate time ratio
 sREMt = sum(inREM);
 sREMl = sum(inREM(idxLaser));
 sWAKt = sum(inWAK);
 sWAKl = sum(inWAK(idxLaser));
 sSWSt = sum(inSWS);
 sSWSl = sum(inSWS(idxLaser));
 set(handles.sumRatio,'string',sprintf('Summary(Laser/Total)\nREM: %s/%s\nWake: %s/%s\nSWS: %s/%s',...
     num2str(sREMl),num2str(sREMt),...
     num2str(sWAKl),num2str(sWAKt),...
     num2str(sSWSl),num2str(sSWSt)));
% save file result
fileSummary.plot1.REM = bsSummmaryREM;
fileSummary.plot2.REM = bsSummmaryREM2;
fileSummary.ratio.WAK = sREMl/sREMt;
fileSummary.plot1.WAK = bsSummmaryWAK;
fileSummary.plot2.WAK = bsSummmaryWAK2;
fileSummary.ratio.WAK = sWAKl/sWAKt;
fileSummary.plot1.SWS = bsSummmarySWS;
fileSummary.plot2.SWS = bsSummmarySWS2;
fileSummary.ratio.SWS = sSWSl/sSWSt;
set(handles.resultPlot2,'userdata',fileSummary);

%reset button
set(handles.processRecording,'value',0);
%set(handles.loadFile,'userdata',[])
function sWindow_Callback(hObject, eventdata, handles)
% hObject    handle to sWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sWindow as text
%        str2double(get(hObject,'String')) returns contents of sWindow as a double


% --- Executes during object creation, after setting all properties.
function sWindow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function updateMsg(hObject, eventdata, handles)
% used for update information panel
msgNum = get(handles.infoPanel,'value');

switch msgNum
    case 1
        msg = 'Please select REM on scatter plot.';
    case 4
        msg = 'Data processing finished.';
    case 2
        msg = 'Please select Wake on scatter plot.';
    case 3
        msg = 'Please select SWS on scatter plot.';
    case 5
        msg = '';
end

set(handles.infoPanel,'string',msg)



function fragmentSize_Callback(hObject, eventdata, handles)
% hObject    handle to fragmentSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fragmentSize as text
%        str2double(get(hObject,'String')) returns contents of fragmentSize as a double


% --- Executes during object creation, after setting all properties.
function fragmentSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fragmentSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveFolder.
function saveFolder_Callback(hObject, eventdata, handles)
% hObject    handle to saveFolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
currentDirectory = pwd;
saveDataFolder = uigetdir(currentDirectory,'Choose a Save Directory');
if saveDataFolder == 0
    return
else
    set(handles.saveFolder,'userdata',saveDataFolder);
end



function fileName_Callback(hObject, eventdata, handles)
% hObject    handle to fileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fileName as text
%        str2double(get(hObject,'String')) returns contents of fileName as a double


% --- Executes during object creation, after setting all properties.
function fileName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SumFolder.
function SumFolder_Callback(hObject, eventdata, handles)
% hObject    handle to SumFolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% delete summary file, if exist.
% try
%     delete('folderSummary.mat');
% catch
% end
% set folder, load data, and process
dataFolder = get(handles.saveFolder,'userdata');
cd(dataFolder)
[fileNames] = dir('*.mat');
sumData.plot1.REM = [];
sumData.plot1.WAK = [];
sumData.plot1.SWS = [];
sumData.plot2.REM = [];
sumData.plot2.WAK = [];
sumData.plot2.SWS = [];
for i = 1:length(fileNames)
    load(fileNames(i).name);
    sumData.plot1.REM = horzcat(sumData.plot1.REM,fileSummary.plot1.REM);
    sumData.plot1.SWS = horzcat(sumData.plot1.SWS,fileSummary.plot1.SWS);
    sumData.plot1.WAK = horzcat(sumData.plot1.WAK,fileSummary.plot1.WAK);
    sumData.plot2.REM = horzcat(sumData.plot2.REM,fileSummary.plot2.REM);
    sumData.plot2.SWS = horzcat(sumData.plot2.SWS,fileSummary.plot2.SWS);
    sumData.plot2.WAK = horzcat(sumData.plot2.WAK,fileSummary.plot2.WAK);
end
save('folderSummary.mat','sumData')
%% update plot
if 0
    trialLength = size(sumData.plot1.REM,1);
    imagesc(sumData.plot1.REM','parent',handles.resultPlot);
    set(handles.resultPlot,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    imagesc(sumData.plot1.WAK','parent',handles.resultPlot3);
    set(handles.resultPlot3,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    imagesc(sumData.plot1.SWS','parent',handles.resultPlot5);
    set(handles.resultPlot5,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    %rem
    plot(mean(sumData.plot2.REM,2),'parent',handles.resultPlot2);
    temp = axis(handles.resultPlot2);
    axis(handles.resultPlot2, [0 trialLength temp(3) temp(4)]);
    set(handles.resultPlot2,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    %wak
    plot(mean(sumData.plot2.WAK,2),'parent',handles.resultPlot4);
    temp = axis(handles.resultPlot4);
    axis(handles.resultPlot4, [0 trialLength temp(3) temp(4)]);
    set(handles.resultPlot4,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    %sws
    plot(mean(sumData.plot2.SWS,2),'parent',handles.resultPlot6);
    temp = axis(handles.resultPlot6);
    axis(handles.resultPlot6, [0 trialLength temp(3) temp(4)]);
    set(handles.resultPlot6,'Visible','on','XTick',[],'YTick',[],'TickLength',[0 0]);
    % update message panel
    set(handles.infoPanel,'string','Current Folder Summary Finished');
else
    figure
    subplot(5,3,[1 4 7 10])
    trialLength = size(sumData.plot1.REM,1);
    imagesc(sumData.plot1.REM');
    title('REM');
    ylabel('All Trials')
    subplot(5,3,1+[1 4 7 10])
    imagesc(sumData.plot1.WAK');
    title('WAK');
    subplot(5,3,2+[1 4 7 10])
    imagesc(sumData.plot1.SWS');
    title('SWS');
    %rem
    subplot(5,3,13)
    data = mean(sumData.plot2.REM,2)/3;
    % relative value
    %plot(data/mean(data(1:19)),'lineWidth',2);  
    plot(data,'lineWidth',2);
    ylabel('Probability')
    hold on
    plot([20 20],[0 max(data/mean(data(1:19)))*1.1],'r')
    %     plot([0 120],[1,1],'g--')
    plot([0 120],[0.5,0.5],'g--')
    hold off
%     axis([0 trialLength 0 max(data/mean(data(1:19)))*1.1]);
 axis([0 trialLength 0 1]);
    %wak
    subplot(5,3,14)
    data = mean(sumData.plot2.WAK,2)/3;
    % relative value
    % plot(data/mean(data(1:19)),'lineWidth',2);
    plot(data,'lineWidth',2);
    hold on
    plot([20 20],[0 max(data/mean(data(1:19)))*1.1],'r')
    %     plot([0 120],[1,1],'g--')
    plot([0 120],[0.5,0.5],'g--')
    hold off
    %     axis([0 trialLength 0 max(data/mean(data(1:19)))*1.1]);
 axis([0 trialLength 0 1]);
    %sws
    subplot(5,3,15)
    data = mean(sumData.plot2.SWS,2)/3;
    % relative value
    % plot(data/mean(data(1:19)),'lineWidth',2);
    plot(data,'lineWidth',2);
    hold on
    plot([20 20],[0 max(data/mean(data(1:19)))*1.1],'r')
    %     plot([0 120],[1,1],'g--')
    plot([0 120],[0.5,0.5],'g--')
    hold off
    %     axis([0 trialLength 0 max(data/mean(data(1:19)))*1.1]);
 axis([0 trialLength 0 1]);
end
