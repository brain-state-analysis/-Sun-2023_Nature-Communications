% laser bootstrap
% zeke barger 083017
function [] = laser_bootstrap()

iters = 10000; % bootstrap iterations
prefix = 'NAC'; % mouse ID prefix, will identify mouse as NTS1, NTS2, etc. if prefix is 'NTS'
% if any mouse number is larger than 9, this won't work!!! it only looks 1
% character past the prefix
laser_len = 120; % length of laser on period, in s
bin_wid = 5; % width of brain state bin
pre_laser_time = 240; % time before laser on, in s
direc = 'G:\Chronic pain and insomnia\D2_ChR2_sleep\summary'; % folder of data files
% all .mat files in this folder will be used!


ourDir = struct2cell(dir(direc))';
isfolder = cell2mat(ourDir(:,5)); % find entries that are folders. on newer versions of MATLAB? set 4 to 5
ourDir = ourDir(~isfolder,1); % remove those
data = {};
sorteddata = {};
whatMouseIsThisFile = [];

for i = 1:length(ourDir)
    loc = strfind(ourDir{1},prefix);
    whatMouseIsThisFile(i) = str2num(ourDir{i}(loc+length(prefix)));
    data{i} = load([direc,'\',ourDir{i}]);
end

mouseIds = sort(unique(whatMouseIsThisFile));
n = length(mouseIds); % number of mice
m = zeros(1,n); % trials per mouse
for i = 1:length(mouseIds)
    sorteddata{i} = [];
    for j = 1:length(ourDir)
        if mouseIds(i) == whatMouseIsThisFile(j)
            sorteddata{i} = cat(1,sorteddata{i},cat(3,data{1,j}.fileSummary.plot2.REM'/3,...
                data{1,j}.fileSummary.plot2.WAK'/3,data{1,j}.fileSummary.plot2.SWS'/3));
            m(i) = size(sorteddata{i},1);
        end
    end 
end

pre_lsr_pts = pre_laser_time / bin_wid;
lsr_pts = laser_len / bin_wid;

diffs = zeros(iters, 3); % pre vs laser difference
for i = 1:iters
    miceAvg = [];
    for j = 1:n % for each mouse
        trials = randi(m(j), m(j), 1); % select trials at random w/ repl
        miceAvg(:,:,j) = squeeze(mean(sorteddata{j}(trials,:,:)))';
    end
    
    avgAcrossMice = mean(miceAvg,3);
    
    for j = 1:3
        diffs(i,j) = mean(avgAcrossMice(j,1:pre_lsr_pts)) - mean(avgAcrossMice(j,(1:lsr_pts)+pre_lsr_pts));
    end
end

% from Franz's code
P = zeros(1,3);
for i=1:3
    if mean(diffs(:,i)) >= 0
        p = length(find(diffs(:,i)>0)) / iters;
        sig = 1 - p;
        if sig == 0, sig = 1/iters; end
    else
        p = length(find(diffs(:,i)<0)) / iters;
        sig = 1 - p;
        if sig == 0, sig = 1/iters; end
    end
    P(i) = sig;
end

disp('p values (pre-laser vs. laser on):')
disp(['REM: ',num2str(P(1))])
disp(['Wake: ',num2str(P(2))])
disp(['NREM: ',num2str(P(3))])